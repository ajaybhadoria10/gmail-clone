import React from 'react';
import './Mail.css'

function Mail() {
    return (
        <div className="mail">
            
        </div>
    )
}

export default Mail
